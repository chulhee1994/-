package VO;
import java.util.ArrayList;
import java.util.List;
public class AirplaneAccountVo extends Abs_AccountVo{
	

	private String air_Name; //VARCHAR2 10
	private String air_Tel;    //VARCHAR2 15
	private String air_code;
	
	

	public String getAir_Name() {
		return air_Name;
	}
	public void setAir_Name(String air_Name) {
		this.air_Name = air_Name;
	}
	public String getAir_Tel() {
		return air_Tel;
	}
	public void setAir_Tel(String air_Tel) {
		this.air_Tel = air_Tel;
	}
	public String getAir_code() {
		return air_code;
	}
	public void setAir_code(String air_code) {
		this.air_code = air_code;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
